import java.awt.*;
import javax.swing.*;

public class resume extends JFrame {
	public resume() {
		super("이력서 작성");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container contentPane = getContentPane();
		
		contentPane.setLayout(null);
		
		JLabel la1 = new JLabel("이력서 명");
		la1.setBounds(22, 0, 257, 44);
		contentPane.add(la1);
		
		JTextField tf1 = new JTextField("");
		tf1.setBounds(22, 40, 242, 34);
		contentPane.add(tf1);
		
		JLabel la2 = new JLabel("최종 학력");
		la2.setBounds(22, 74, 257, 44);
		contentPane.add(la2);
		
		JTextField tf2 = new JTextField("");
		tf2.setBounds(22, 114, 242, 34);
		contentPane.add(tf2);
		
		JLabel la3 = new JLabel("토익 점수");
		la3.setBounds(22, 148, 257, 44);
		contentPane.add(la3);
		
		JTextField tf3 = new JTextField("");
		tf3.setBounds(22, 188, 242, 34);
		contentPane.add(tf3);
		
		JLabel la4 = new JLabel("해외 경험 횟수");
		la4.setBounds(22, 222, 257, 44);
		contentPane.add(la4);
		
		JTextField tf4 = new JTextField("");
		tf4.setBounds(22, 262, 242, 34);
		contentPane.add(tf4);

		JButton bt1 = new JButton("닫기");
		bt1.setBounds(538, 387, 92, 37);
		contentPane.add(bt1);
		
		JButton bt2 = new JButton("경력 추가");
		bt2.setBounds(297, 112, 107, 36);
		contentPane.add(bt2);
		
		JTextField tf5 = new JTextField("");
		tf5.setBounds(297, 150, 303, 146);
		contentPane.add(tf5);
		
		JButton bt3 = new JButton("삭제");
		bt3.setBounds(530, 307, 70, 24);
		contentPane.add(bt3);
		
		setSize(669, 456);
		setVisible(true);
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new resume();
	}

}
